# Capstone compliance checklist (C1-C10)

Status is produced by checking that each evidence file exists when this script runs, not by assertion.

## C1 - Security analytics lifecycle — **COMPLETE** (5/5 evidence files present)
- **Evidence:** all 5 sources
- **What was done:** Lifecycle from collection to action is implemented as stages s01-s16 with a log of every run.
- **Files:** `outputs/tables/data_inventory.csv`, `outputs/tables/cleaning_log.csv`, `outputs/tables/eda_findings.csv`, `outputs/tables/incident_response_plan.csv`, `outputs/logs/run_log.txt`
- **Remaining / caveat:** Feedback loop is documented but not yet automated (no re-labelling workflow).

## C2 - Multi-source data (>=3, incl. identity/access and network/OT) — **COMPLETE** (4/4 evidence files present)
- **Evidence:** 5 source families, 635k+ records
- **What was done:** IIoT telemetry, network flows, identity/access, ticket text, ATT&CK ICS text, plus asset/user context.
- **Files:** `outputs/tables/data_inventory.csv`, `outputs/tables/minimum_data_check.csv`, `data/raw/synthetic_remote_access_log.csv`, `data/raw/mining_asset_inventory.csv`
- **Remaining / caveat:** Access log and tickets are synthetic; this must be stated in the report and defence.

## C3 - Data engineering and baseline — **COMPLETE** (5/5 evidence files present)
- **Evidence:** dictionary + 37 cleaning actions + baselines
- **What was done:** Provenance hashes, quality findings, role/user/telemetry/network baselines.
- **Files:** `outputs/tables/data_dictionary.csv`, `outputs/tables/cleaning_log.csv`, `outputs/tables/baseline_access_role.csv`, `outputs/tables/baseline_telemetry.csv`, `outputs/figures/fig08_login_hour_by_role.png`
- **Remaining / caveat:** Network flow source has no timestamp column, so time-based joins to it are not possible.

## C4 - Machine learning (supervised + unsupervised) — **COMPLETE** (4/4 evidence files present)
- **Evidence:** 3 supervised models, IF/LOF/DBSCAN
- **What was done:** Confusion matrices, precision, recall, F1, ROC-AUC, PR-AUC, permutation importance.
- **Files:** `outputs/tables/supervised_network_test.csv`, `outputs/tables/supervised_modbus_test.csv`, `outputs/tables/anomaly_access_validation.csv`, `outputs/figures/fig09_confusion_network.png`
- **Remaining / caveat:** Scores on ToN_IoT are high because the capture is a controlled testbed.

## C5 - Security investigation — **COMPLETE** (3/3 evidence files present)
- **Evidence:** 202-row timeline with evidence IDs
- **What was done:** Case ranked from evidence, entities identified, four-phase response plan.
- **Files:** `outputs/tables/incident_timeline.csv`, `outputs/tables/incident_affected_entities.csv`, `outputs/tables/incident_response_plan.csv`
- **Remaining / caveat:** The case is an analytical scenario built on synthetic access data, clearly labelled.

## C6 - Security intelligence — **COMPLETE** (4/4 evidence files present)
- **Evidence:** 5 PIRs, ATT&CK mapping, 2 products
- **What was done:** Operational watchlist for the SOC and an executive brief with modelled effects.
- **Files:** `outputs/tables/intel_requirements.csv`, `outputs/tables/intel_attack_mapping.csv`, `outputs/tables/intel_operational_watchlist.csv`, `outputs/intelligence_executive_brief.md`
- **Remaining / caveat:** ATT&CK mapping is TF-IDF similarity, not an analyst-validated mapping.

## C7 - Simulation of >=3 control scenarios — **COMPLETE** (3/3 evidence files present)
- **Evidence:** 5 scenarios x 5,000 runs + sensitivity
- **What was done:** Monte Carlo propagation over the asset graph with Wilson confidence intervals.
- **Files:** `outputs/tables/simulation_summary.csv`, `outputs/tables/simulation_sensitivity.csv`, `outputs/figures/fig20_simulation_scenarios.png`
- **Remaining / caveat:** Transmission probabilities are assumed; only p_foothold is measured from data.

## C8 - Text mining / NLP — **COMPLETE** (4/4 evidence files present)
- **Evidence:** 677 text records, classify + extract + topics
- **What was done:** Preprocessing, TF-IDF classification with a confusion matrix, indicator extraction scored against an answer key, NMF topics, ATT&CK enrichment.
- **Files:** `outputs/tables/nlp_ticket_classification.csv`, `outputs/tables/nlp_extracted_indicators.csv`, `outputs/tables/nlp_attack_topics.csv`, `outputs/tables/nlp_ticket_attack_enrichment.csv`
- **Remaining / caveat:** Ticket text is template-generated, so classification accuracy is optimistic.

## C9 - Predictive risk + >=3 adversarial tests — **COMPLETE** (4/4 evidence files present)
- **Evidence:** risk score + 4 test families
- **What was done:** Six-component interpretable score with bands, next-day early warning, and drift/evasion/missing-data/poisoning tests.
- **Files:** `outputs/tables/risk_user_day_scores.csv`, `outputs/tables/risk_band_summary.csv`, `outputs/tables/risk_forecast_metrics.csv`, `outputs/tables/adversarial_results.csv`
- **Remaining / caveat:** Next-day forecast is weak (ROC-AUC ~0.53); reported as a negative result.

## C10 - Decision-support prototype — **COMPLETE** (3/3 evidence files present)
- **Evidence:** Streamlit console (8 views) + notebook
- **What was done:** Analyst can inspect events, baselines, anomalies, model results, risk, the incident and the intelligence products.
- **Files:** `app/app.py`, `notebooks/capstone_walkthrough.ipynb`, `outputs/figures/fig26_architecture.png`
- **Remaining / caveat:** Prototype reads pre-computed outputs; it does not yet ingest live data.
